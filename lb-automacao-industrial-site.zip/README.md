# LB Automação Industrial

Site pronto para publicar na Vercel.

## Como usar
1. Envie para GitHub ou upload direto na Vercel.
2. Deploy.
